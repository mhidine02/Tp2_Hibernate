package entities;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "machines")
public class Machine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "reference")
    private String ref;
    @Temporal(TemporalType.DATE)
    private Date dateAchat;
    private double prix;

    @ManyToOne
    @JoinColumn(name = "salle_id")
    private Salle salle;

    public Machine() {
    }

    public Machine(String ref, Date dateAchat, double prix, Salle salle) {
        this.ref = ref;
        this.dateAchat = dateAchat;
        this.prix = prix;
        this.salle = salle;
    }

    public Machine(String m123, Date date, Salle byId) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public Date getDateAchat() {
        return dateAchat;
    }

    public void setDateAchat(Date dateAchat) {
        this.dateAchat = dateAchat;
    }

    public double getPrix() {
        return prix;
    }

    public void setPrix(double prix) {
        this.prix = prix;
    }

    public Salle getSalle() {
        return salle;
    }

    public void setSalle(Salle salle) {
        this.salle = salle;
    }




}

